package com.mindInk.app.ui.theme

import androidx.compose.ui.graphics.Color

val MindInkBlack = Color(0xFF0A0A0A)
val MindInkBackground = Color(0xFF131313)
val MindInkSurface = Color(0xFF141414)
val MindInkSurfaceVariant = Color(0xFF1C1C1C)
val MindInkInputSurface = Color(0xFF303030)
val MindInkBorder = Color(0xFF2A2A2A)

val MindInkWhite = Color(0xFFFFFFFF)
val MindInkMuted = Color(0xFF9E9E9E)
val MindInkDim = Color(0xFF6B6B6B)

val MindInkRed = Color(0xFFE53935)
val MindInkRedDark = Color(0xFFB71C1C)
val MindInkError = Color(0xFFFF6B6B)

val MindInkStar = Color(0xFFFFD54F)

val EventBorderBlue = Color(0xFF4285F4)
val EventBorderGreen = Color(0xFF0F9D58)
val EventBorderGray = Color(0xFF696969)
val EventBorderRed = Color(0xFFDB4437)
val EventBorderYellow = Color(0xFFF4B400)

val EventBorderColors = listOf(
    EventBorderBlue,
    EventBorderGreen,
    EventBorderGray,
    EventBorderRed,
    EventBorderYellow,
    EventBorderBlue
)