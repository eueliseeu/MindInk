package com.mindInk.app.ui.auth

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindInk.app.core.ConnectivityObserver
import com.mindInk.app.domain.model.AuthProvider
import com.mindInk.app.domain.model.AuthUser
import com.mindInk.app.domain.repository.AuthErrorReason
import com.mindInk.app.domain.repository.SignInResult
import com.mindInk.app.domain.usecase.auth.DiscardPendingLinkUseCase
import com.mindInk.app.domain.usecase.auth.LinkPendingAccountUseCase
import com.mindInk.app.domain.usecase.auth.ObserveAuthStateUseCase
import com.mindInk.app.domain.usecase.auth.SignInWithGitHubUseCase
import com.mindInk.app.domain.usecase.auth.SignInWithGoogleUseCase
import com.mindInk.app.domain.usecase.auth.SignOutUseCase
import com.mindInk.app.domain.usecase.profile.EnsureUserProfileUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    observeAuthStateUseCase: ObserveAuthStateUseCase,
    private val ensureUserProfile: EnsureUserProfileUseCase,
    private val signInWithGoogleUseCase: SignInWithGoogleUseCase,
    private val signInWithGitHubUseCase: SignInWithGitHubUseCase,
    private val linkPendingAccountUseCase: LinkPendingAccountUseCase,
    private val discardPendingLinkUseCase: DiscardPendingLinkUseCase,
    private val signOutUseCase: SignOutUseCase,
    private val connectivityObserver: ConnectivityObserver
) : ViewModel() {

    private var ensuredProfileUid: String? = null

    val sessionState: StateFlow<SessionState> = observeAuthStateUseCase()
        .onEach { user -> user?.let(::ensureProfileOnce) }
        .map { user ->
            if (user != null) SessionState.Authenticated(user) else SessionState.Unauthenticated
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SessionState.Loading
        )

    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private var connectivityJob: Job? = null

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _errorEvents = Channel<AuthErrorReason>(Channel.BUFFERED)
    val errorEvents: Flow<AuthErrorReason> = _errorEvents.receiveAsFlow()

    @OptIn(FlowPreview::class)
    fun onAppStarted() {
        if (connectivityObserver.isCurrentlyOnline()) {
            _isOnline.value = true
        }

        connectivityJob?.cancel()
        connectivityJob = viewModelScope.launch {
            connectivityObserver.observe()
                .debounce { online -> if (online) 0L else OFFLINE_DEBOUNCE_MS }
                .collect { online -> _isOnline.value = online }
        }
    }

    fun onAppStopped() {
        connectivityJob?.cancel()
        connectivityJob = null
    }

    fun onGoogleClick(activity: Activity) {
        launchSignIn(AuthProvider.GOOGLE) { signInWithGoogleUseCase(activity) }
    }

    fun onGitHubClick(activity: Activity) {
        launchSignIn(AuthProvider.GITHUB) { signInWithGitHubUseCase(activity) }
    }

    fun onConfirmLink(activity: Activity) {
        val request = _uiState.value.linkRequest ?: return
        launchSignIn(request.existingProvider) { linkPendingAccountUseCase(activity) }
    }

    fun onDismissLink() {
        discardPendingLinkUseCase()
        _uiState.value = AuthUiState()
    }

    fun onSignOutClick() {
        viewModelScope.launch { signOutUseCase() }
    }

    private fun ensureProfileOnce(user: AuthUser) {
        if (ensuredProfileUid == user.uid) return
        viewModelScope.launch {
            if (ensureUserProfile(user)) ensuredProfileUid = user.uid
        }
    }

    private fun launchSignIn(provider: AuthProvider, block: suspend () -> SignInResult) {
        if (_uiState.value.isLoading) return
        _uiState.value = AuthUiState(loadingProvider = provider)

        viewModelScope.launch {
            val result = block()

            _uiState.value = when (result) {
                is SignInResult.Success, SignInResult.Cancelled, is SignInResult.Error ->
                    AuthUiState()

                is SignInResult.LinkRequired -> AuthUiState(
                    linkRequest = LinkRequest(
                        pendingProvider = result.pendingProvider,
                        existingProvider = result.existingProvider
                    )
                )
            }

            if (result is SignInResult.Error) {
                _errorEvents.send(result.reason)
            }
        }
    }

    private companion object {
        const val OFFLINE_DEBOUNCE_MS = 1_200L
    }
}