package com.mindInk.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalResources
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.mindInk.app.ui.articles.ArticlesScreen
import com.mindInk.app.ui.articles.community.CommunityArticlesScreen
import com.mindInk.app.ui.articles.detail.ArticleDetailScreen
import com.mindInk.app.ui.articles.editor.CreateEditArticleScreen
import com.mindInk.app.ui.articles.stars.LocalStarredArticleIds
import com.mindInk.app.ui.articles.stars.StarredArticlesViewModel
import com.mindInk.app.ui.auth.AuthViewModel
import com.mindInk.app.ui.auth.LinkAccountDialog
import com.mindInk.app.ui.auth.LoginScreen
import com.mindInk.app.ui.auth.SessionState
import com.mindInk.app.ui.auth.toMessageRes
import com.mindInk.app.ui.components.ToastHost
import com.mindInk.app.ui.components.ToastMessage
import com.mindInk.app.ui.home.GuestArticleDetailScreen
import com.mindInk.app.ui.home.GuestAuthorProfileScreen
import com.mindInk.app.ui.home.GuestHomeScreen
import com.mindInk.app.ui.profile.AuthorProfileScreen
import com.mindInk.app.ui.settings.AccountSettingsScreen
import com.mindInk.app.ui.splash.OfflineScreen
import com.mindInk.app.ui.splash.SplashScreen
import com.mindInk.app.ui.theme.AppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()
    private val starredArticlesViewModel: StarredArticlesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AppTheme {
                val resources by rememberUpdatedState(LocalResources.current)
                val viewModel = authViewModel
                val session by viewModel.sessionState.collectAsState()
                val uiState by viewModel.uiState.collectAsState()
                val isOnline by viewModel.isOnline.collectAsState()
                val starredIds by starredArticlesViewModel.starredIds.collectAsState()
                var showSplash by rememberSaveable { mutableStateOf(true) }
                var showLogin by rememberSaveable { mutableStateOf(false) }
                var showCreateArticle by rememberSaveable { mutableStateOf(false) }
                var showCommunityArticles by rememberSaveable { mutableStateOf(false) }
                var showAccountSettings by rememberSaveable { mutableStateOf(false) }
                var profileNameOverride by rememberSaveable { mutableStateOf<String?>(null) }
                var profileNameOverrideUid by rememberSaveable { mutableStateOf<String?>(null) }
                var selectedArticleId by rememberSaveable { mutableStateOf<String?>(null) }
                var selectedAuthorUid by rememberSaveable { mutableStateOf<String?>(null) }
                var toast by remember { mutableStateOf<ToastMessage?>(null) }

                val isAuthenticated = session is SessionState.Authenticated && !uiState.isLoading

                val canNavigateBack = when {
                    isAuthenticated ->
                        selectedArticleId != null ||
                            selectedAuthorUid != null ||
                            showCreateArticle ||
                            showCommunityArticles ||
                            showAccountSettings
                    else ->
                        showLogin ||
                            selectedArticleId != null ||
                            selectedAuthorUid != null
                }

                BackHandler(enabled = canNavigateBack) {
                    when {
                        selectedArticleId != null -> selectedArticleId = null
                        selectedAuthorUid != null -> selectedAuthorUid = null
                        showCreateArticle -> showCreateArticle = false
                        showCommunityArticles -> showCommunityArticles = false
                        showAccountSettings -> showAccountSettings = false
                        showLogin -> showLogin = false
                    }
                }

                LaunchedEffect(isAuthenticated) {
                    if (isAuthenticated) {
                        showLogin = false
                    }
                }

                LaunchedEffect(viewModel) {
                    viewModel.errorEvents.collect { reason ->
                        toast = ToastMessage(resources.getString(reason.toMessageRes()))
                    }
                }

                CompositionLocalProvider(LocalStarredArticleIds provides starredIds) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (showSplash || session is SessionState.Loading) {
                            SplashScreen(
                                onFinished = { showSplash = false }
                            )
                        } else if (!isOnline) {
                            OfflineScreen()
                        } else {
                            val current = session
                            when {
                                current is SessionState.Authenticated && !uiState.isLoading -> {
                                    val currentUser = current.user.copy(
                                        displayName = profileNameOverride
                                            ?.takeIf { profileNameOverrideUid == current.user.uid }
                                            ?: current.user.displayName
                                    )
                                    val openMyProfile: () -> Unit = {
                                        selectedArticleId = null
                                        showCreateArticle = false
                                        showCommunityArticles = false
                                        showAccountSettings = false
                                        selectedAuthorUid = current.user.uid
                                    }
                                    val openAccountSettings: () -> Unit = {
                                        selectedArticleId = null
                                        selectedAuthorUid = null
                                        showCreateArticle = false
                                        showCommunityArticles = false
                                        showAccountSettings = true
                                    }

                                    when {
                                        showAccountSettings -> {
                                            AccountSettingsScreen(
                                                user = currentUser,
                                                onBack = { showAccountSettings = false },
                                                onSignOut = viewModel::onSignOutClick,
                                                onAccountDeleted = {
                                                    showAccountSettings = false
                                                    selectedArticleId = null
                                                    selectedAuthorUid = null
                                                    showCreateArticle = false
                                                    showCommunityArticles = false
                                                    profileNameOverride = null
                                                    profileNameOverrideUid = null
                                                },
                                                onProfileUpdated = { newName ->
                                                    profileNameOverride = newName
                                                    profileNameOverrideUid = currentUser.uid
                                                }
                                            )
                                        }

                                        selectedArticleId != null -> {
                                            selectedArticleId?.let { articleId ->
                                                ArticleDetailScreen(
                                                    articleId = articleId,
                                                    user = currentUser,
                                                    onBack = { selectedArticleId = null },
                                                    onSignOut = viewModel::onSignOutClick,
                                                    onProfileClick = openMyProfile,
                                                    onSettingsClick = openAccountSettings
                                                )
                                            }
                                        }

                                        selectedAuthorUid != null -> {
                                            selectedAuthorUid?.let { authorUid ->
                                                AuthorProfileScreen(
                                                    authorUid = authorUid,
                                                    user = currentUser,
                                                    onBack = { selectedAuthorUid = null },
                                                    onArticleClick = { card ->
                                                        selectedAuthorUid = null
                                                        selectedArticleId = card.id
                                                    },
                                                    onSignOut = viewModel::onSignOutClick,
                                                    onProfileClick = openMyProfile,
                                                    onSettingsClick = openAccountSettings
                                                )
                                            }
                                        }

                                        showCreateArticle -> {
                                            CreateEditArticleScreen(
                                                user = currentUser,
                                                onBack = { showCreateArticle = false },
                                                onSaved = {
                                                    showCreateArticle = false
                                                    toast = ToastMessage("Seu artigo foi publicado.")
                                                },
                                                onSignOut = viewModel::onSignOutClick,
                                                onProfileClick = openMyProfile,
                                                onSettingsClick = openAccountSettings
                                            )
                                        }

                                        showCommunityArticles -> {
                                            CommunityArticlesScreen(
                                                user = currentUser,
                                                onBack = { showCommunityArticles = false },
                                                onSignOut = viewModel::onSignOutClick,
                                                onProfileClick = openMyProfile,
                                                onSettingsClick = openAccountSettings,
                                                onArticleClick = { card ->
                                                    selectedArticleId = card.id
                                                },
                                                onCreateArticleClick = {
                                                    showCreateArticle = true
                                                }
                                            )
                                        }

                                        else -> {
                                            ArticlesScreen(
                                                user = currentUser,
                                                onSignOut = viewModel::onSignOutClick,
                                                onProfileClick = openMyProfile,
                                                onSettingsClick = openAccountSettings,
                                                onAddArticleClick = {
                                                    showCommunityArticles = true
                                                },
                                                onArticleClick = { card ->
                                                    selectedArticleId = card.id
                                                },
                                                onAuthorClick = { author ->
                                                    selectedAuthorUid = author.uid
                                                }
                                            )
                                        }
                                    }
                                }

                                else -> {
                                    showCreateArticle = false
                                    showCommunityArticles = false
                                    showAccountSettings = false

                                    when {
                                        showLogin -> {
                                            LoginScreen(
                                                loadingProvider = uiState.loadingProvider,
                                                onGoogleClick = {
                                                    viewModel.onGoogleClick(this@MainActivity)
                                                },
                                                onGitHubClick = {
                                                    viewModel.onGitHubClick(this@MainActivity)
                                                }
                                            )
                                        }

                                        selectedArticleId != null -> {
                                            GuestArticleDetailScreen(
                                                articleId = selectedArticleId!!,
                                                onBack = { selectedArticleId = null },
                                                onMyAccountClick = {
                                                    selectedArticleId = null
                                                    showLogin = true
                                                }
                                            )
                                        }

                                        selectedAuthorUid != null -> {
                                            GuestAuthorProfileScreen(
                                                authorUid = selectedAuthorUid!!,
                                                onBack = { selectedAuthorUid = null },
                                                onArticleClick = { card ->
                                                    selectedAuthorUid = null
                                                    selectedArticleId = card.id
                                                },
                                                onAccessMoreClick = {
                                                    selectedAuthorUid = null
                                                    showLogin = true
                                                }
                                            )
                                        }

                                        else -> {
                                            GuestHomeScreen(
                                                onMyAccountClick = { showLogin = true },
                                                onArticleClick = { card ->
                                                    selectedArticleId = card.id
                                                },
                                                onAuthorClick = { author ->
                                                    selectedAuthorUid = author.uid
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        ToastHost(
                            message = toast,
                            onDismiss = { toast = null }
                        )

                        uiState.linkRequest?.let { request ->
                            LinkAccountDialog(
                                request = request,
                                onConfirm = { viewModel.onConfirmLink(this@MainActivity) },
                                onDismiss = viewModel::onDismissLink
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        authViewModel.onAppStarted()
    }

    override fun onStop() {
        authViewModel.onAppStopped()
        super.onStop()
    }
}